//
//  Utilities.swift
//  Assignment4
//
//  Created by Esha Chiplunkar on 10/2/24.
//

import Foundation

class Utilities {
    static let typesOfPhones = ["Cell", "Work", "Home"]
}
